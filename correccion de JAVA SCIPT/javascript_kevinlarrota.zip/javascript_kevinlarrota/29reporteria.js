import {
  larrotaSumar as larrotaSumaSimple,
  larrotaSumarDoble as larrotaSumaConMultiplicador
} from './29.js';

console.log("Larrota Suma simple:", larrotaSumaSimple(4, 6)); 
console.log("Larrota Suma doble:", larrotaSumaConMultiplicador(7, 3)); 

//Palabra clave "as"
//Permite renombrar una importación
//para evitar conflictos de nombres o
//hacer el código más claro

