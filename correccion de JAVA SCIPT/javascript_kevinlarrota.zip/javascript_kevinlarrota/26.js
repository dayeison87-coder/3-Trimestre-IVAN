export default function larrota(a, b) {
  return a + b;
}