export function larrotaSumar(x, y) {
  return x + y;
}

export function larrotaSumarDoble(x, y) {
  return (x + y) * 2;
}