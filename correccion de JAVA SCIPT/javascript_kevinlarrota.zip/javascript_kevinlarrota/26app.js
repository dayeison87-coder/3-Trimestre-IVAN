import operacionLarrota from './26.js';

const resultadoLarrota = operacionLarrota(8, 7);
console.log("Resultado Larrota:", resultadoLarrota);
