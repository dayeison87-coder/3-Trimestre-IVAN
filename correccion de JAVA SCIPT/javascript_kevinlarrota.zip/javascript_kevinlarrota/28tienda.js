import LarrotaAuto from './28.js';

const larrotaVehiculo = new LarrotaAuto("LarrotaMotors", "TurboX");

console.log("Nuevo vehículo Larrota:");
console.log(larrotaVehiculo.obtenerLarrotaDescripcion());




