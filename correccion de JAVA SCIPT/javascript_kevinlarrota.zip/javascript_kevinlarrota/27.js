export const LARROTA_VERSION = "1.0.0";

export function saludarLarrotaUsuario(nombreLarrota) {
  return `Hola ${nombreLarrota}. Versión: ${LARROTA_VERSION}`;
}

export const LARROTA_MAX_USUARIOS = 100;
